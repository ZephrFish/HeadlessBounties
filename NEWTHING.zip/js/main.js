	var strings = {
	    first: ['Penetration Tester', 'Bug Bounty Hunter', 'Martial Artist', 'Hacker'
	    ],
		second: ['cat ab', 'cat aboutme.txt'],
		third: ['Secret Lair', 'Homepage', 'Blog' ]
	}
	$('.txt')
	    .typed({
	        strings: strings.first,
	        typeSpeed: 100,
	        backDelay: 1500,
	        callback: function() {
	            $('.typed-cursor')
	                .fadeOut()
	        }
	    })
	
	$('.cmd')
	    .typed({
	        strings: strings.second,
	        typeSpeed: 100,
	        backDelay: 200,
	        callback: function() {
	            $('.typed-cursor')
	                .fadeOut()
	        }
	    })
		
	$('.blog')
	    .typed({
	        strings: strings.third,
	        typeSpeed: 150,
	        backDelay: 200,
	        callback: function() {
	            $('.typed-cursor')
	                .fadeOut()
	        }
	    })	
	